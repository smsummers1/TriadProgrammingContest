import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by labsu14 on 4/5/2018.
 */
public class Main {
    public static void main(String[] args)
    {
        Integer[] raw = null;
        ArrayList<AccidentData> data = new ArrayList<>();

        try {
            Scanner in = new Scanner(System.in);
             raw = GetRawIntsFromFile(in.nextLine());
             in.close();
        } catch (NumberFormatException e)
        {
            System.out.println("Invalid data!");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            try
            {
                for (int i = 0; i < raw.length; i =i)
                {
                    int day = raw[i++];
                    int month = raw[i++];
                    int dayof = raw[i++];
                    int hour = raw[i++];
                    int minute = raw[i++];
                    int drunkDrv = raw[i++];

                    data.add(new AccidentData(day, month, dayof, hour, minute, drunkDrv));
                }
            }
            catch(ArrayIndexOutOfBoundsException e)
            {
                System.out.println("Invalid data! Wrong amount of integers in file.");
            }
            finally{
                int totalDrunkAccidents=0;
                int[] totalDrunkAccidentsOnHour = new int[14*7];

                for (int i = 0; i < totalDrunkAccidentsOnHour.length; i ++)
                {
                    totalDrunkAccidentsOnHour[i] = 0;
                }

                for(int i = 0; i < data.size(); i ++)
                {
                    if (data.get(i).getHasDrunkDriver())
                    {
                        totalDrunkAccidents++;
                        totalDrunkAccidentsOnHour[(data.get(i).getDayOfWeek()-1)*23 + data.get(i).getHour()]++;
                    }
                }

                int lowestIndex = -1;
                int lowestValue = Integer.MAX_VALUE;
                int highestIndex = -1;
                int highestValue = -1;

                for (int i = 0; i < totalDrunkAccidentsOnHour.length; i++)
                {
                    if (totalDrunkAccidentsOnHour[i] > highestValue)
                    {
                        highestIndex = i;
                        highestValue = totalDrunkAccidentsOnHour[i];
                    }

                    if (totalDrunkAccidentsOnHour[i] < lowestValue)
                    {
                        lowestIndex = i;
                        lowestValue = totalDrunkAccidentsOnHour[i];
                    }
                }

                String lowestPercent = Float.toString((totalDrunkAccidentsOnHour[lowestIndex] / (float)totalDrunkAccidents)*100f) + "%";
                String highestPercent = Float.toString((totalDrunkAccidentsOnHour[highestIndex] / (float)totalDrunkAccidents)*100f) + "%";
                String lowestDay = GetDayName((lowestIndex/24)+1);
                String highestDay = GetDayName((highestIndex/24)+1);
                String lowestTime = String.valueOf(lowestIndex%24) + ":00";
                String highestTime = String.valueOf(highestIndex %24) + ":00";


                System.out.println("Most drunk accidents " + highestPercent + " on " + highestDay + " at " + highestTime);
                System.out.println("Least drunk accidents " + lowestPercent + " on " + lowestDay + " at " + lowestTime);



            }

        }


    }

    public static Integer[] GetRawIntsFromFile(String fileName) throws IOException, NumberFormatException  {
        ArrayList<Integer> ret = new ArrayList<>();

        File file = new File(fileName);

        if(file.exists()) {
        }
        Scanner s = new Scanner(file);
        while (s.hasNext()) {
            String[] toks = s.nextLine().split("\t");
            int cur = 0;
            for (int i = 0; i < toks.length; i++) {
                ret.add(Integer.parseInt(toks[i]));
            }
        }

        return ret.toArray(new Integer[ret.size()]);
    }

    public static String GetDayName(int i)
    {
        switch(i)
        {
            case 1:
                return "Sunday";
            case 2:
                return "Monday";
            case 3:
                return "Tuesday";
            case 4:
                return "Wednesday";
            case 5:
                return "Thursday";
            case 6:
                return "Friday";
            case 7:
                return "Saturday";
        }
        return null;
    }
}
