/**
 * Created by labsu14 on 4/5/2018.
 */
public class AccidentData {
    int Day;

    public AccidentData(int day, int month, int dayOfWeek, int hour, int minute, int drunkDrivers) {
        Day = day;
        Month = month;
        DayOfWeek = dayOfWeek;
        this.hour = hour;
        this.minute = minute;
        this.drunkDrivers = drunkDrivers;
    }

    int Month;
    int DayOfWeek;
    int hour;
    int minute;
    int drunkDrivers;

    public int getDay() {
        return Day;
    }

    public int getMonth() {
        return Month;
    }

    public int getDayOfWeek() {
        return DayOfWeek;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getDrunkDrivers() {
        return drunkDrivers;
    }
    public Boolean getHasDrunkDriver()
    {
        return drunkDrivers > 0;
    }
}

