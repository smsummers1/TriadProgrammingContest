import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Created by labsu14 on 4/5/2018.
 */
public class Main {
    public static void main(String[] args)
    {
        Random r = new Random();
        int maxLaneCount = 10;
        int minutes = 100000;
        float s=0;
        float p=0;
        float w=0;
        try {
            Float[] raw = GetInput("C:\\Users\\LabSu14\\Downloads\\inputCorrected\\inputCorrected\\grocery.txt");
            s = raw[0];
            p = raw[1];
            w = raw[2];
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        finally{
            float[] costs = new float[10];
            for (int curLaneCount = 1; curLaneCount <= 10; curLaneCount++)
            {
                costs[curLaneCount-1] = 0f;
                CheckoutLine[] lines = new CheckoutLine[curLaneCount];
                for (int i = 0; i < lines.length; i ++)
                {
                    lines[i] = new CheckoutLine();
                }
                for (int m = 0; m < minutes; m ++)
                {
                    if(r.nextFloat()%1<p)
                    {
                        int shortestLine = 0;
                        int shortestLineAmount = Integer.MAX_VALUE;
                        for(int l = 0; l < lines.length; l ++)
                        {
                            if (lines[l].CustomersInLine < shortestLineAmount)
                            {
                                shortestLine = l;
                                shortestLineAmount = lines[l].CustomersInLine;
                            }
                        }
                        lines[shortestLine].CustomersInLine++;

                        for (int l = 0; l < lines.length; l ++)
                        {
                            if (lines[l].MinutesTillTakeCustomer < r.nextInt() % 4 + 3)
                            {
                                lines[l].MinutesTillTakeCustomer=0;
                                lines[l].CustomersInLine = Math.max(0,lines[l].CustomersInLine-1);
                            }

                            lines[l].MinutesTillTakeCustomer++;
                            costs[curLaneCount-1] += lines[l].CustomersInLine * w + s;
                        }


                    }
                }
            }
            float lowestCost= Float.MAX_VALUE;
            int lowestIndex = -1;
            for (int i = 0; i < costs.length; i ++)
            {
                if (costs[i] < lowestCost)
                {
                    lowestIndex = i;
                    lowestCost = costs[i];
                }
            }

            System.out.println(lowestIndex +1);
        }

    }

    public static Float[] GetInput(String fileName) throws FileNotFoundException {
        ArrayList<Float> ret = new ArrayList<>();

        File f = new File(fileName);
        if (f.exists())
        {
            Scanner s = new Scanner(f);
            while(s.hasNext())
            {
                String[] dat = s.nextLine().split("\t");
                for (int i = 0; i < dat.length; i++)
                {
                    ret.add(Float.parseFloat(dat[i]));
                }
            }
        }

        return ret.toArray(new Float[ret.size()]);
    }
}
