/**
 * Created by labsu14 on 4/5/2018.
 */
public class CheckoutLine {
    public int CustomersInLine = 0;
    public int MinutesTillTakeCustomer = 0;
}
